# text-to-QR
 This is the github repo for the text-to-QR chrome extension
